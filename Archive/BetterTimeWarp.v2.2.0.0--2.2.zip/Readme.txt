#Better Time Warp

Forum thread: forum.kerbalspaceprogram.com/threads/85926

BetterTimeWarp is a mod for Kerbal Space Program that enables customized time warping.

To install:

1. Merge GameData folder with the one in your KSP folder
2. Done!