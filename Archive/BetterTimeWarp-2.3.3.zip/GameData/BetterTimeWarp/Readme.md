#Better Time Warp

Forum thread: http://forum.kerbalspaceprogram.com/index.php?/topic/154935-*

BetterTimeWarp is a mod for Kerbal Space Program that enables customized time warping.

To install:

1. Merge GameData folder with the one in your KSP folder
2. Done!


Instructions

You can access the UI in one of two ways, either by clicking the B button on the toolbar, or , in the flight scene, clicking the down button at the top, right next to the clock (in 1.2.2, it is right now on top of the probe-control icon, will be fixed)

Once the UI is opened,�