#Better Time Warp

Forum thread: http://forum.kerbalspaceprogram.com/index.php?/topic/154935-*

BetterTimeWarp is a mod for Kerbal Space Program that enables customized time warping.

To install:

1. Merge GameData folder with the one in your KSP folder
2. Done!
