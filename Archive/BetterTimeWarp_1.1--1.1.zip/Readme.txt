BetterTimeWarp is a mod for Kerbal Space Program that enables customized time warping.

To install:

1. Merge GameData folder with the one in your KSP folder
2. Done!